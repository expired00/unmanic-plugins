
Enter a comma separated list of language codes to search for during library scans and new file event triggers.

Any video files with audio streams having tags that match these language codes listed here will be removed from their files.

---

#### Examples:

###### <span style="color:magenta">Remove Japanese and French streams</span>
```
jp,fr
```
