
**<span style="color:#56adda">1.0.3</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">1.0.2</span>**
- Fix Python bug in stream mapping 

**<span style="color:#56adda">1.0.1</span>**
- Limit plugin to only process files with a "video" mimetype

**<span style="color:#56adda">1.0.0</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Update icon

**<span style="color:#56adda">0.0.2</span>**
- Keep the output file out in the same container as the source

**<span style="color:#56adda">0.0.1</span>**
- Initial version
