# Ignore files under size

plugin for [Unmanic](https://github.com/Unmanic)
