# Strip all image streams from file

plugin for [Unmanic](https://github.com/Unmanic)
