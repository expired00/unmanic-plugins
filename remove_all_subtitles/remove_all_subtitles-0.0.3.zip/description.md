
This is useful if you intend to supply your own subtitles for your library.
