# Video Encoder H265/HEVC - hevc_qsv

plugin for [Unmanic](https://github.com/Unmanic)
