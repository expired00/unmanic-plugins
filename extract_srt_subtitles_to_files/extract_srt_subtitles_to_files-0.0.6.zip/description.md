
Any SRT subtitle streams found in the file will be exported as *.srt files in the same directory as the original file.

To include other formats, such as ASS, consider first converting the subtitle streams to SRT using the Plugin(s) 
- **"Convert any ASS subtitle streams in videos to SRT"**
Configure the Plugin flow to set these first

#### <span style="color:gray">Note:</span>
> This Plugin does not contain a file tester to detect files that contain SRT subtitle streams.
> Ensure it is pared with another Plugin.
