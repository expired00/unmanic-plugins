# Video Encoder H264 - h264_nvenc

plugin for [Unmanic](https://github.com/Unmanic)
